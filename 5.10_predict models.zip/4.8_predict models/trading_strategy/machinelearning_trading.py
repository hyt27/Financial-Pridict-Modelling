import pandas as pd
import pylab as plt

######开盘买收盘卖
def buy_and_sell_in_one_day(whole_predict,logpath,balance = 100000,fees = 0):
    ###trading 在开盘时，如果预测今天的close比开盘价高则买入

    yield_curve = pd.DataFrame(index=whole_predict.index, columns=['balance', 'return','benchmark'])
    origin_balance = balance      ###原始本金
    origin_price =  whole_predict['act_close'].iloc[0]
    yesterday = whole_predict['act_close'].iloc[0]
    start = yesterday

    for i,row in whole_predict.iterrows():
        today = row['pred_close']
        if today > yesterday:
        # if today > row['open']:   ##如果预测收盘价结果大于开盘价

            ####开盘价买入
            buy_num = balance // row['open']    ##要买多少只
            balance = balance - buy_num * row['open'] - buy_num * row['open'] * fees  ###买完之后账户余额


            ###收盘价卖出
            balance = balance + buy_num * row['act_close']   ###卖出后余额

            today_yield = (row['act_close']-row['open']) * buy_num  ###当日收益


            with open(logpath, "a") as file:
                file.write('DATE:'+ str(row['Date'])+' buy '+ str(buy_num) + ' at '+ str(row['open']) + '  sell at ' + str(row['act_close']) + ' pred_close=' + str(row['pred_close']) + '  todayield:' + str(today_yield) + 'balance:' + str(balance) + "\n")  # 写入日志消息并添加换行符

        yesterday = row['act_close']


        yield_curve.loc[i, 'balance'] = balance
        date_difference = (row['Date'] - whole_predict.index.min()).days + 1

        
        yield_curve.loc[i, 'return'] = ((balance/origin_balance - 1)/date_difference) * 365

        yield_curve.loc[i, 'benchmark'] = ((row['act_close']/origin_price - 1)/date_difference) * 365


    yield_rate = balance/origin_balance-1

    start_date = whole_predict.index.min()
    end_date = whole_predict.index.max()

    # 计算日期差
    date_difference = (end_date - start_date).days
    year_rate = (yield_rate / date_difference) * 365

    benchmark_yield = ((row['act_close']/origin_price - 1)/date_difference) * 365     
    print('balance:' + str(balance) + ' yield rate:' + str(year_rate*100) + '%')
    print('benchimark yield:'+ str(benchmark_yield*100) + '%')

    plt.figure(figsize=(24,8))

    
    plt.ylim(-100,100)

    plt.plot(yield_curve.index,yield_curve['return']*100,label = 'return')
    plt.plot(yield_curve.index,yield_curve['benchmark']*100,label = 'benchmark')

    plt.xlabel('Date')
    plt.ylabel('year yield rate %')
    
    
    plt.gcf().autofmt_xdate()
    plt.title('return  vs benchmark on BankofQingdao')
    plt.legend()
    plt.show()



######开盘买开盘买（通过预测决定哪天卖）
def buy_and_select_when_sell(whole_predict,logpath,balance = 100000,tax = 0.001,fees = 0.0003):
    ###trading 在开盘时，如果预测今天的close比开盘价高则买入
    print(whole_predict)

    yield_curve = pd.DataFrame(index=whole_predict.index, columns=['balance', 'return','benchmark'])
    origin_balance = balance      ###原始本金
    origin_price =  whole_predict['act_close'].iloc[0]
    ####初始化
    today_sell = False
    today_buy = False
    num_stock = 0       ##持有股票数
    # today_buy = False
    hadstock = False  ###当前是否持仓

    for i,row in whole_predict.iterrows():

        today_sell = False
        today_buy = False

        ########盘前决策######################################
        if hadstock == True:
            if nextday_sell == True:     ####开盘卖出
                ###今日决策
                today_sell = True     #####今天决定要卖 
                today_buy = False   
            
            elif whole_predict.index.get_loc(i) == len(whole_predict)-1:   ###如果今天是最后一天则卖出
                today_sell = True
                today_buy = False 

            ####反之继续持仓，跳到收盘决策步


        elif hadstock == False:    ####当前未持仓，要决定是否买入

            if whole_predict.index.get_loc(i)-1 > 0:
                yesterday_row = whole_predict.iloc[whole_predict.index.get_loc(i)-1]
            else:
                yesterday_row  = whole_predict.iloc[0]
            if whole_predict.index.get_loc(i) == len(whole_predict)-1:
                today_sell = False
                today_buy = False 
            elif row['pred_close'] > yesterday_row['act_close']:
                ###今日决策
                today_sell = False
                today_buy = True     ###今天决定要买
            elif whole_predict.index.get_loc(i) == len(whole_predict)-1:   ###如果今天是最后一天则卖出
                today_sell = False
                today_buy = False
    
        ########盘前决策结束##################################
            


        ########日内交易##################################

        if today_sell == True:    ####执行卖出
            balance = balance + num_stock * row['open'] - buy_num * row['open'] * (tax+fees)  ###卖出后余额
            hadstock = False
            
            with open(logpath, "a") as file:
                file.write('DATE:'+ str(row['Date'])+' sell '+ str(num_stock) + ' at '+ str(row['open']) + ' balance:' + str(balance) + "\n")  # 写入日志消息并添加换行符
            
            num_stock = 0
        if today_buy == True:     #####执行买入
            ####开盘价买入
            buy_num = balance // (row['open'] * (1+fees))    ##要买多少只
            balance = balance - buy_num * row['open'] - buy_num * row['open'] * fees  ###买完之后账户余额
            num_stock = buy_num
            hadstock = True

            with open(logpath, "a") as file:
                file.write('DATE:'+ str(row['Date'])+' buy '+ str(buy_num) + ' at '+ str(row['open']) + ' balance:' + str(balance) + "\n")  # 写入日志消息并添加换行符

        ########日内交易结束##################################





        #########盘后决策######################################

        if hadstock == True:
            if i + pd.Timedelta(days=1) < whole_predict.index.max():
                next_row = whole_predict.iloc[whole_predict.index.get_loc(i)+1]

                if next_row['pred_close'] < row['act_close']:    #####如果预测明天会跌则决定明天开盘卖出
                    nextday_sell = True
                else:                                           ####反之明天不卖继续持仓
                    nextday_sell = False

        #########盘后决策结束######################################

        ####记录
        # with open(logpath, "a") as file:
        #     file.write('DATE:'+ str(row['Date'])+' buy '+ str(buy_num) + ' at '+ str(row['open']) + ' balance:' + str(balance) + "\n")  # 写入日志消息并添加换行符


        #####记录每天余额和收益
        yield_curve.loc[i, 'balance'] = balance 
        date_difference = (row['Date'] - whole_predict.index.min()).days + 1

        
        yield_curve.loc[i, 'return'] = (((balance+ num_stock * row['act_close'])/origin_balance - 1)/date_difference) * 365

        yield_curve.loc[i, 'benchmark'] = ((row['act_close']/origin_price - 1)/date_difference) * 365


    ##########循环结束#################

    yield_rate = balance/origin_balance-1


    start_date = whole_predict.index.min()
    end_date = whole_predict.index.max()

    # 计算日期差
    date_difference = (end_date - start_date).days
    year_rate = (yield_rate / date_difference) * 365

    benchmark_yield = ((row['act_close']/origin_price - 1)/date_difference) * 365     
    print('balance:' + str(balance) + ' yield rate:' + str(year_rate*100) + '%')
    print('benchimark yield:'+ str(benchmark_yield*100) + '%')

    plt.figure(figsize=(24,8))

    # plt.ylim(-100,200)

    plt.plot(yield_curve.index,yield_curve['return']*100,label = 'return')
    plt.plot(yield_curve.index,yield_curve['benchmark']*100,label = 'benchmark')

    plt.xlabel('Date')
    plt.ylabel('year yield rate %')
    
    
    plt.gcf().autofmt_xdate()
    plt.title('return  vs benchmark on BankofQingdao')
    plt.legend()
    plt.show()


