######布林带策略
from predict_v2 import predict
from lstm_train import lstm_train
import pylab as plt
import pandas as pd
import joblib
import matplotlib.dates as mdates
from trading_strategy.technical_trading import momentum_strategy
# lstm_train('stock_data/0066.HK.csv',"2010-01-01","2020-06-30",num_epochs=200)
stocks = ["AAPL", "GOOGL", "MSFT", "AMZN","TSLA", "BRK-A", "V", "JNJ", "WMT"]


startdate = '2020-05-01'
enddate = '2024-04-30'

momentum_strategy(stocks,20,startdate,enddate)
