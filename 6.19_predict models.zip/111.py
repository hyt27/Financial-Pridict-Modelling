import numpy
print(numpy.__version__)